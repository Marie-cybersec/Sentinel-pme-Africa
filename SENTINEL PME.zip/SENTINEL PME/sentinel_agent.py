"""
SENTINEL PME AFRICA - Agent de surveillance reseau
==================================================
Installe sur la machine Windows cible (192.168.157.20).
Detecte les vraies attaques reseau et envoie les alertes au SOC.

Installation :
    pip install psutil requests
    python sentinel_agent.py
"""

import psutil
import requests
import threading
import time
import socket
import hashlib
from datetime import datetime, timezone
from collections import defaultdict

# ── Configuration ─────────────────────────────────────────────────────────────
SOC_URL       = "http://192.168.157.10:8000"
PME_ID        = "PME-CM-YDE-001"
AGENT_VERSION = "1.0.0"
HOSTNAME      = socket.gethostname()
LOCAL_IP      = "192.168.157.20"   # IP fixe de la machine Windows

# ── Seuils de detection ───────────────────────────────────────────────────────
SCAN_PORTS_THRESHOLD     = 8    # ports distincts en 10 secondes = scan
BRUTEFORCE_THRESHOLD     = 3    # connexions sur ports auth en 20s = brute force
CPU_RANSOMWARE_THRESHOLD = 85   # % CPU anormal = ransomware suspect
AUTH_PORTS = {22, 23, 21, 445, 3389, 5900}

# ── IP a ignorer (reseau local legitime) ──────────────────────────────────────
IGNORED_PREFIXES = ("127.", "::1", "0.", "169.254.")
IGNORED_IPS      = {LOCAL_IP, "192.168.157.10"}

# ── Processus Windows systeme a ignorer ───────────────────────────────────────
SYSTEM_PROCS = {
    "system", "system idle process", "registry", "smss.exe",
    "csrss.exe", "wininit.exe", "winlogon.exe", "services.exe",
    "lsass.exe", "svchost.exe", "dwm.exe", "explorer.exe",
    "taskhostw.exe", "sihost.exe", "fontdrvhost.exe", "runtimebroker.exe",
    "searchhost.exe", "startmenuexperiencehost.exe", "antimalware service executable",
    "msmpeng.exe", "securityhealthsystray.exe",
}

# ── Memoire interne ───────────────────────────────────────────────────────────
scan_tracker  = defaultdict(lambda: {"ports": set(), "times": []})
brute_tracker = defaultdict(list)
alerted       = set()
lock          = threading.Lock()


def make_id(threat_type, ip):
    raw = f"{threat_type}-{ip}-{time.time()}"
    return hashlib.sha256(raw.encode()).hexdigest()[:16].upper()


def is_ignored(ip):
    if any(ip.startswith(p) for p in IGNORED_PREFIXES):
        return True
    if ip in IGNORED_IPS:
        return True
    return False


def send_alert(payload):
    try:
        requests.post(f"{SOC_URL}/api/alerts", json=payload, timeout=4)
        src = payload["source_ip"]
        dst = payload["target_ip"]
        typ = payload["threat_type"]
        sev = payload["severity"]
        print(f"[+] ALERTE | {typ} | {sev} | {src} → {dst}")
    except Exception as e:
        print(f"[-] SOC inaccessible : {e}")


# ── Module 1 : Detection scan de ports (Nmap) ─────────────────────────────────
def watch_scan():
    WINDOW = 10
    while True:
        now = time.time()
        try:
            conns = psutil.net_connections(kind="inet")
        except Exception:
            time.sleep(3)
            continue

        with lock:
            for c in conns:
                if not c.raddr:
                    continue
                ip = c.raddr.ip
                if is_ignored(ip):
                    continue
                if c.status in ("SYN_RECV", "ESTABLISHED", "SYN_SENT", "CLOSE_WAIT"):
                    scan_tracker[ip]["ports"].add(c.laddr.port)
                    scan_tracker[ip]["times"].append(now)

            for ip, data in list(scan_tracker.items()):
                data["times"] = [t for t in data["times"] if now - t < WINDOW]
                if not data["times"]:
                    del scan_tracker[ip]
                    continue
                if len(data["ports"]) >= SCAN_PORTS_THRESHOLD:
                    key = f"SCAN_{ip}"
                    if key not in alerted:
                        alerted.add(key)
                        ports = sorted(data["ports"])
                        send_alert({
                            "alert_id":    make_id("PORT_SCAN", ip),
                            "pme_id":      PME_ID,
                            "threat_type": "PORT_SCAN",
                            "severity":    "ELEVE",
                            "confidence":  0.95,
                            "source_ip":   ip,
                            "target_ip":   LOCAL_IP,
                            "hostname":    HOSTNAME,
                            "ports_scanned": ports[:20],
                            "port_count":  len(ports),
                            "description": (
                                f"Scan de ports detecte depuis {ip} "
                                f"vers {LOCAL_IP} ({HOSTNAME}). "
                                f"{len(ports)} ports sondes en {WINDOW}s. "
                                f"Outil probable : Nmap."
                            ),
                            "recommended_actions": [
                                f"Bloquer immediatement l'IP {ip} dans le pare-feu Windows.",
                                f"Verifier si d'autres machines ont ete scannees depuis {ip}.",
                                "Ne pas eteindre la machine — les preuves sont en memoire RAM.",
                                "Alerter le responsable securite de l'organisation.",
                            ],
                            "proactive": (
                                f"Apres ce scan, {ip} va probablement tenter une attaque "
                                "par force brute sur les ports ouverts (22, 445, 3389). "
                                "Fermez ces ports dans le pare-feu si vous ne les utilisez pas."
                            ),
                            "detected_at": datetime.now(timezone.utc).isoformat(),
                        })
                        threading.Timer(45, alerted.discard, args=[key]).start()

        time.sleep(3)


# ── Module 2 : Detection brute force (Hydra) ──────────────────────────────────
def watch_brute():
    WINDOW = 20
    while True:
        now = time.time()
        try:
            conns = psutil.net_connections(kind="inet")
        except Exception:
            time.sleep(1)
            continue

        with lock:
            for c in conns:
                if not c.raddr:
                    continue
                if c.laddr.port not in AUTH_PORTS:
                    continue
                ip = c.raddr.ip
                if is_ignored(ip):
                    continue
                # Hydra genere SYN_SENT, ESTABLISHED, TIME_WAIT, CLOSE_WAIT
                if c.status in ("SYN_SENT", "ESTABLISHED", "TIME_WAIT",
                                "CLOSE_WAIT", "LAST_ACK", "FIN_WAIT1",
                                "FIN_WAIT2", "SYN_RECV", "NONE", ""):
                    brute_tracker[ip].append(now)

            for ip, times in list(brute_tracker.items()):
                recent = [t for t in times if now - t < WINDOW]
                brute_tracker[ip] = recent
                if len(recent) >= BRUTEFORCE_THRESHOLD:
                    key = f"BRUTE_{ip}"
                    if key not in alerted:
                        alerted.add(key)
                        send_alert({
                            "alert_id":    make_id("BRUTE_FORCE", ip),
                            "pme_id":      PME_ID,
                            "threat_type": "BRUTE_FORCE",
                            "severity":    "CRITIQUE",
                            "confidence":  0.97,
                            "source_ip":   ip,
                            "target_ip":   LOCAL_IP,
                            "hostname":    HOSTNAME,
                            "attempts":    len(recent),
                            "window_sec":  WINDOW,
                            "description": (
                                f"Attaque par force brute depuis {ip} "
                                f"vers {LOCAL_IP} ({HOSTNAME}). "
                                f"{len(recent)} tentatives de connexion en {WINDOW}s "
                                f"sur les ports SSH/RDP/SMB."
                            ),
                            "recommended_actions": [
                                f"Bloquer l'IP {ip} dans le pare-feu immediatement.",
                                "Changer tous les mots de passe des comptes Windows exposes.",
                                "Desactiver le compte Administrateur local si inutilise.",
                                "Activer l'authentification a deux facteurs.",
                                "Debrancher le cable reseau si l'attaque continue.",
                            ],
                            "proactive": (
                                f"Si {ip} obtient des identifiants valides, il peut "
                                "acceder a d'autres machines du reseau et installer "
                                "un ransomware. Isolez cette machine maintenant."
                            ),
                            "detected_at": datetime.now(timezone.utc).isoformat(),
                        })
                        threading.Timer(60, alerted.discard, args=[key]).start()

        time.sleep(1)


# ── Module 3 : Detection ransomware comportemental ────────────────────────────
def watch_ransomware():
    while True:
        try:
            for proc in psutil.process_iter(["pid", "name", "cpu_percent", "exe"]):
                try:
                    info = proc.info
                    cpu  = info.get("cpu_percent") or 0
                    name = (info.get("name") or "").lower().strip()
                    if name in SYSTEM_PROCS:
                        continue
                    if not name:
                        continue
                    if cpu > CPU_RANSOMWARE_THRESHOLD:
                        pid = info["pid"]
                        key = f"RANSOM_{pid}"
                        with lock:
                            if key not in alerted:
                                alerted.add(key)
                                send_alert({
                                    "alert_id":    make_id("RANSOMWARE", LOCAL_IP),
                                    "pme_id":      PME_ID,
                                    "threat_type": "RANSOMWARE_SUSPECT",
                                    "severity":    "CRITIQUE",
                                    "confidence":  0.82,
                                    "source_ip":   LOCAL_IP,
                                    "target_ip":   LOCAL_IP,
                                    "hostname":    HOSTNAME,
                                    "process":     info.get("name"),
                                    "pid":         pid,
                                    "cpu_percent": cpu,
                                    "description": (
                                        f"Processus '{info.get('name')}' (PID {pid}) "
                                        f"consomme {cpu:.0f}% CPU sur {HOSTNAME} ({LOCAL_IP}). "
                                        "Comportement suspect — possible chiffrement de fichiers."
                                    ),
                                    "recommended_actions": [
                                        f"Ouvrir le Gestionnaire des taches et terminer le PID {pid}.",
                                        f"Deconnecter {HOSTNAME} du reseau immediatement.",
                                        "Ne pas eteindre — les preuves sont en memoire RAM.",
                                        "Verifier les fichiers modifies dans les 10 dernieres minutes.",
                                        "Restaurer depuis la derniere sauvegarde saine.",
                                    ],
                                    "proactive": (
                                        "Si ce processus est un ransomware actif, "
                                        "tous vos fichiers seront chiffres dans quelques minutes. "
                                        "Isolez la machine maintenant avant qu'il soit trop tard."
                                    ),
                                    "detected_at": datetime.now(timezone.utc).isoformat(),
                                })
                                threading.Timer(120, alerted.discard, args=[key]).start()
                except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                    pass
        except Exception as e:
            print(f"[-] Erreur module ransomware : {e}")
        time.sleep(8)


# ── Module 4 : Heartbeat ──────────────────────────────────────────────────────
def heartbeat():
    while True:
        try:
            requests.post(f"{SOC_URL}/api/heartbeat", json={
                "pme_id":    PME_ID,
                "hostname":  HOSTNAME,
                "ip":        LOCAL_IP,
                "cpu":       psutil.cpu_percent(interval=1),
                "ram":       psutil.virtual_memory().percent,
                "version":   AGENT_VERSION,
                "status":    "ACTIVE",
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }, timeout=4)
        except Exception:
            pass
        time.sleep(30)


# ── Point d'entree ────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--soc-url", default=SOC_URL)
    parser.add_argument("--pme-id",  default=PME_ID)
    args = parser.parse_args()
    SOC_URL = args.soc_url
    PME_ID  = args.pme_id

    print(f"""
SENTINEL PME AFRICA - Agent v{AGENT_VERSION}
Serveur SOC : {SOC_URL}
Machine     : {HOSTNAME} ({LOCAL_IP})
Surveillance : active
""")

    threads = [
        threading.Thread(target=watch_scan,       name="ScanWatcher",  daemon=True),
        threading.Thread(target=watch_brute,      name="BruteWatcher", daemon=True),
        threading.Thread(target=watch_ransomware, name="RansoWatcher", daemon=True),
        threading.Thread(target=heartbeat,        name="Heartbeat",    daemon=True),
    ]
    for t in threads:
        t.start()
        print(f"  Module actif : {t.name}")

    print("\nSurveillance en cours. Ctrl+C pour arreter.\n")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nAgent arrete.")