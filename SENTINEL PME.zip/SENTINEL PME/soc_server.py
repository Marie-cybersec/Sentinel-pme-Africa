"""
SENTINEL PME AFRICA - Serveur SOC
==================================
Installe sur Ubuntu Server (192.168.157.10).

Lancement :
    pip3 install fastapi uvicorn websockets --break-system-packages
    python3 soc_server.py

Dashboard :
    Ouvrir http://192.168.157.10:8080/dashboard.html dans un navigateur
    (lancer aussi : python3 -m http.server 8080)
"""

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from datetime import datetime, timezone
import uvicorn

app = FastAPI(title="SENTINEL SOC", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

alerts   = []
agents   = {}
clients  = []


def risk_score():
    if not alerts:
        return 0
    score = 0
    for a in alerts[-20:]:
        s = a.get("severity", "")
        if s == "CRITIQUE": score += 35
        elif s == "ELEVE":  score += 20
        elif s == "MOYEN":  score += 10
    return min(100, score)

def risk_label(score):
    if score >= 70: return "CRITIQUE"
    if score >= 40: return "ELEVE"
    if score >= 15: return "MOYEN"
    return "FAIBLE"

async def push(msg):
    dead = []
    for ws in clients:
        try:
            await ws.send_json(msg)
        except Exception:
            dead.append(ws)
    for ws in dead:
        if ws in clients:
            clients.remove(ws)


@app.get("/")
async def root():
    return {"status": "running", "service": "SENTINEL PME AFRICA SOC"}

@app.post("/api/alerts")
async def receive_alert(alert: dict):
    alert["received_at"] = datetime.now(timezone.utc).isoformat()
    alerts.append(alert)
    sc = risk_score()
    await push({"type": "ALERT", "alert": alert, "risk": sc, "risk_label": risk_label(sc)})
    return {"ok": True}

@app.post("/api/heartbeat")
async def heartbeat(data: dict):
    agents[data.get("pme_id", "?")] = data
    await push({"type": "HEARTBEAT", "agent": data})
    return {"ok": True}

@app.get("/api/alerts")
async def get_alerts():
    sc = risk_score()
    return {"alerts": alerts[-50:], "total": len(alerts), "risk": sc, "risk_label": risk_label(sc)}

@app.get("/api/agents")
async def get_agents():
    return list(agents.values())

@app.delete("/api/alerts")
async def clear():
    alerts.clear()
    await push({"type": "CLEAR"})
    return {"ok": True}

@app.websocket("/ws")
async def ws_endpoint(ws: WebSocket):
    await ws.accept()
    clients.append(ws)
    sc = risk_score()
    await ws.send_json({
        "type": "INIT",
        "alerts": alerts[-30:],
        "agents": list(agents.values()),
        "risk": sc,
        "risk_label": risk_label(sc),
    })
    try:
        while True:
            await ws.receive_text()
    except WebSocketDisconnect:
        if ws in clients:
            clients.remove(ws)


if __name__ == "__main__":
    print("SENTINEL PME AFRICA - Serveur SOC")
    print("API  : http://0.0.0.0:8000")
    print("Docs : http://192.168.157.10:8000/docs")
    uvicorn.run(app, host="0.0.0.0", port=8000)
